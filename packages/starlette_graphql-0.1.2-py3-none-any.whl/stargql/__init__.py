from .applications import GraphQL  # noqa
